export default function BlogEdit() {
  return (
    <div className="blog-edit-page">
      <h1>Edit Blog Post</h1>
      {/* Blog edit form will go here */}
    </div>
  );
}
