import { useAuthContext } from "./useAuthContext";

export const useAuth = () => {
  return useAuthContext();
};
